using FluentEmojiKitchen.Services;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace FluentEmojiKitchen
{
    public sealed partial class MainWindow : Window
    {
        // Initial state upon loading: window not visible.
        private bool _isPopupVisible = false;

        // Calling AppWindow.Show()/Hide() can itself trigger Activated event handler while TogglePopupVisibility is still running.
        // We set a flag to indicate that we are still in the midst of changing states.
        private bool _isProgrammaticToggle;
        private Models.EmojiItemViewModel? _selectedEmoji;
        private IntPtr _previousForegroundWindow;

        public MainWindow()
        {
            // Initialize contents in MainWindow.xaml
            this.InitializeComponent();
            // Makes TabStripGrid in the associated .xaml the title bar (enables repositioning of window)
            SetTitleBar(TabStripGrid);

            SystemBackdrop = new Microsoft.UI.Xaml.Media.DesktopAcrylicBackdrop();
            // Removes the native system bar.
            ExtendsContentIntoTitleBar = true;

            // Configuration of window position and sizing
            if (AppWindow.Presenter is OverlappedPresenter presenter)
            {
                presenter.IsResizable = false;
                presenter.IsMaximizable = false;
                presenter.IsMinimizable = false;
                presenter.SetBorderAndTitleBar(true, false);
                presenter.IsAlwaysOnTop = true;
            }

            AppWindow.Resize(new Windows.Graphics.SizeInt32(360, 420));
            AppWindow.IsShownInSwitchers = false; // hide from Alt+Tab

            // Hide from the taskbar itself
            IntPtr hWnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
            int exStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
            exStyle |= WS_EX_TOOLWINDOW;
            exStyle &= ~WS_EX_APPWINDOW;
            SetWindowLong(hWnd, GWL_EXSTYLE, exStyle);

            AppWindow.Closing += OnAppWindowClosing;
            this.Activated += OnWindowActivated;
            SetAppIcon();
        }

        private void OnAppWindowClosing(AppWindow sender, AppWindowClosingEventArgs args)
        {
            // Cancels actually closing the application.
            args.Cancel = true;
            TogglePopupVisibility();
        }

        private void OnWindowActivated(object sender, WindowActivatedEventArgs args)
        {
            if (_isProgrammaticToggle) return; // if we are in the midst of toggling, dont toggle again

            if (args.WindowActivationState == WindowActivationState.Deactivated)
            {
                TogglePopupVisibility();
            }
        }

        public void TogglePopupVisibility()
        {
            _isProgrammaticToggle = true;

            if (_isPopupVisible)
                AppWindow.Hide();
            else
            {
                _previousForegroundWindow = GetForegroundWindow();
                SetAllFocus();
                AppWindow.Show();
            }

            _isPopupVisible = !_isPopupVisible;

            // Vs. resetting the flag synchronously, inline; guard will have expired and will not catch the bug outlined above.
            DispatcherQueue.TryEnqueue(() => _isProgrammaticToggle = false);
        }

        private void OnCloseButtonClick(object sender, RoutedEventArgs e) => TogglePopupVisibility();

        private void SetAllFocus()
        {
            // another way to get window focus from background state lol (the above is kinda inconsistent)
            IntPtr hWnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
            SetForegroundWindow(hWnd);
            // Then, focus the emoji search bar.
            DispatcherQueue.TryEnqueue(() => SearchBox.Focus(FocusState.Programmatic));
        }

        private void SetAppIcon()
        {
            string iconPath = Path.Combine(AppContext.BaseDirectory, "Assets/Icons/AppIcon.ico");
            if (File.Exists(iconPath))
                this.AppWindow.SetIcon(iconPath);
        }

        private void OnEmojiTabClick(object sender, RoutedEventArgs e)
        {
            EmojiTabButton.IsChecked = true;
            KitchenTabButton.IsChecked = false;
            EmojiTabContent.Visibility = Visibility.Visible;
            KitchenTabContent.Visibility = Visibility.Collapsed;
        }

        private void OnKitchenTabClick(object sender, RoutedEventArgs e)
        {
            EmojiTabButton.IsChecked = false;
            KitchenTabButton.IsChecked = true;
            EmojiTabContent.Visibility = Visibility.Collapsed;
            KitchenTabContent.Visibility = Visibility.Visible;
        }

        public void SetEmojiData(EmojiDataService emojiDataService)
        {
            LoadingText.Visibility = Visibility.Collapsed;
            EmojiTabContent.Visibility = Visibility.Visible;

            EmojiRepeater.ItemsSource = emojiDataService.Emojis
                .Select(e => new Models.EmojiItemViewModel(e))
                .ToList();
        }

        private async void OnEmojiItemClick(object sender, TappedRoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("click detected");
            if (sender is FrameworkElement { Tag: Models.EmojiItemViewModel vm })
            {
                if(_selectedEmoji != vm && _selectedEmoji is not null)
                {
                    _selectedEmoji.IsSelected = false;
                }
                vm.IsSelected = true;
                _selectedEmoji = vm;

                // e.g. copy to clipboard
                //var dataPackage = new Windows.ApplicationModel.DataTransfer.DataPackage();
                //dataPackage.SetText(vm.Character);
                //Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(dataPackage);
                System.Diagnostics.Debug.WriteLine(vm.Character);
                await InsertWithoutHidingPopup(vm.Character);

            }
        }


        private async System.Threading.Tasks.Task InsertWithoutHidingPopup(string character)
        {
            // Suppress the Deactivated->hide handler for the moment we hand focus
            // back to the target app — we are NOT calling Show/Hide here at all,
            // so the popup window stays visible the whole time.
            _isProgrammaticToggle = true;

            SetForegroundWindow(_previousForegroundWindow);
            await System.Threading.Tasks.Task.Delay(60);
            EmojiInsertionService.InsertText(character);

            DispatcherQueue.TryEnqueue(() => _isProgrammaticToggle = false);
        }

        private void OnEmojiPointerEntered(object sender, PointerRoutedEventArgs e)
        {
            if (sender is FrameworkElement root && root.FindName("HoverLayer") is Border hover)
                hover.Opacity = 1;
        }

        private void OnEmojiPointerExited(object sender, PointerRoutedEventArgs e)
        {
            if (sender is FrameworkElement root && root.FindName("HoverLayer") is Border hover)
                hover.Opacity = 0;
        }


        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_APPWINDOW = 0x00040000;

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
    }
}